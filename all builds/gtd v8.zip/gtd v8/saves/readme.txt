if you edit these files things may break
you can delete a file and then run the game to recreate the missing files with the default values
if the game cannot find the 'saves' folder it will not create the files
DO NOT DELETE THE SAVES FOLDER